function enviar(){
	
	var nome   = document.getElementById("idNomeUser").value;
	var senha1 = document.getElementById("idSenha").value;
	var senha2 = document.getElementById("idRepSenha").value;

	if(nome == ''){
		alert("Entre com o nome do usuário.");
		return false;
	}
	if(nome.length < 10){
		alert("O nome do usuário deve ter 10 caracteres.");
		return false;
	}

	if(senha1 == ''){
		alert("Entre com uma senha.");
		return false;
	}
	if(senha1.length < 6){
		alert("Entre com uma senha válida.");
		return false;
	}
	if (senha1[0] != '1' && senha1[0] != '2' && senha1[0] != '3' && senha1[0] != '4' && senha1[0] != '5' && senha1[0] != '6' && senha1[0] != '7' && senha1[0] != '8' && senha1[0] != '9'){
		alert("Entre com uma senha válida.");
		return false;
	}

	if(senha2 == ''){
		alert("Entre com uma senha novamente.");
		return false;
	}

	if(senha1 != senha2){
		alert("As senha não são iguais.");
		return false;
	}
	alert("Dados enviados!\nNome: "+nome+"\nSenha: "+senha1);

	var form = document.getElementById("myform");
	form.submit();	
}