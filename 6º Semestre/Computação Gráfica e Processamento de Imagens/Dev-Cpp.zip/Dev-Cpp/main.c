#include <stdio.h>
main( )
{
char nome, end, cid;
int tel, cep;
printf ("Digite o seu nome:\n");
scanf("%s", &nome);
printf ("Digite a seu endereco:\n");
scanf ("%s", &end);
printf("Digite sua cidade :\n");
scanf ("%s", &cid);
printf("Digite sueu telefone :\n");
scanf ("%d", &tel);
printf("Digite seu CEP :\n");
scanf ("%f", &cep);

}
